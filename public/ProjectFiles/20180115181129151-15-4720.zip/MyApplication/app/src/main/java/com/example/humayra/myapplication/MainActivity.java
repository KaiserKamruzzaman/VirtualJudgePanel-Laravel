package com.example.humayra.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CheckBox check1,check2,check3;
    private RadioButton bdt,usd,cad;
    private EditText amountText,vatPercentage,vatAmount;
    private Button vatCalbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        check1 = (CheckBox)findViewById(R.id.checkBox1);
        check2 = (CheckBox)findViewById(R.id.checkBox2);
        check3 = (CheckBox)findViewById(R.id.checkBox3);

        bdt = (RadioButton) findViewById(R.id.bdtradiobtn);
        usd = (RadioButton) findViewById(R.id.usdradiobtn);
        cad = (RadioButton) findViewById(R.id.cadusdbtn);




    }

    public void OnCheck1Click(View v)
    {
        check2.setChecked(false);
        check3.setChecked(false);
    }

    public void OnCheck2Click(View v)
    {
        check1.setChecked(false);
        check3.setChecked(false);
    }

    public void OnCheck3Click(View v)
    {
        check1.setChecked(false);
        check2.setChecked(false);
    }

    public void OnBDTradioClick(View v)
    {
        usd.setChecked(false);
        cad.setChecked(false);
    }

    public void OnUSDradioClick(View v)
    {
        bdt.setChecked(false);
        cad.setChecked(false);
    }

    public void OnCADradioClick(View v)
    {
        usd.setChecked(false);
        bdt.setChecked(false);
    }


    public void onButtonClick(View v)
    {
        amountText = (EditText)findViewById(R.id.amount);
        vatPercentage = (EditText)findViewById(R.id.vatpercentage);
        vatAmount = (EditText)findViewById(R.id.vatamount);

        int num1 = Integer.parseInt(amountText.getText().toString());
        int num2 = Integer.parseInt(vatPercentage.getText().toString());
        int vatAmt = num1 * num2 / 100 ;
        vatAmount.setText(Integer.toString(vatAmt));
    }






}
